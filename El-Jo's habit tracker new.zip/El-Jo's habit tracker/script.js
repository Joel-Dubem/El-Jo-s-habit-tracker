// ==========================================
// EL-JO'S HABIT TRACKER
// ==========================================

// ---------- STORAGE ----------

let habits = JSON.parse(
    localStorage.getItem("eljoHabits")
) || [];

let records = JSON.parse(
    localStorage.getItem("eljoRecords")
) || {};


// ---------- GET ELEMENTS ----------

const addHabitBtn = document.getElementById("addHabitBtn");
const habitForm = document.getElementById("habitForm");

const saveHabitBtn = document.getElementById("saveHabitBtn");
const cancelHabitBtn = document.getElementById("cancelHabitBtn");

const habitName = document.getElementById("habitName");
const habitIcon = document.getElementById("habitIcon");
const dailyGoal = document.getElementById("dailyGoal");
const reminderTime = document.getElementById("reminderTime");

const habitsContainer = document.getElementById("habitsContainer");
const emptyState = document.getElementById("emptyState");


// ==========================================
// ADD HABIT BUTTON
// ==========================================

addHabitBtn.onclick = function () {

    console.log("Add Habit button clicked");

    habitForm.classList.remove("hidden");

    habitName.focus();

};


// ==========================================
// CANCEL BUTTON
// ==========================================

cancelHabitBtn.onclick = function () {

    habitForm.classList.add("hidden");

    clearForm();

};


// ==========================================
// SAVE HABIT
// ==========================================

saveHabitBtn.onclick = function () {

    const name = habitName.value.trim();

    const icon = habitIcon.value;

    const goal = Number(dailyGoal.value);

    const reminder = reminderTime.value;


    // Check habit name

    if (name === "") {

        alert("Please enter a habit name.");

        habitName.focus();

        return;

    }


    // Check goal

    if (!goal || goal < 1) {

        alert("Please enter a valid daily goal.");

        dailyGoal.focus();

        return;

    }


    // Create habit

    const newHabit = {

        id: Date.now().toString(),

        name: name,

        icon: icon,

        goal: goal,

        reminder: reminder

    };


    habits.push(newHabit);


    // Save

    saveData();


    // Clear and hide form

    clearForm();

    habitForm.classList.add("hidden");


    // Refresh app

    renderHabits();

    updateDashboard();


    alert(
        `"${name}" has been added! 🌱`
    );

};


// ==========================================
// CLEAR FORM
// ==========================================

function clearForm() {

    habitName.value = "";

    habitIcon.value = "📚";

    dailyGoal.value = 30;

    reminderTime.value = "";

}


// ==========================================
// SAVE DATA
// ==========================================

function saveData() {

    localStorage.setItem(
        "eljoHabits",
        JSON.stringify(habits)
    );

    localStorage.setItem(
        "eljoRecords",
        JSON.stringify(records)
    );

}


// ==========================================
// DATE
// ==========================================

function getDateKey(date = new Date()) {

    const year = date.getFullYear();

    const month = String(
        date.getMonth() + 1
    ).padStart(2, "0");

    const day = String(
        date.getDate()
    ).padStart(2, "0");

    return `${year}-${month}-${day}`;

}


// ==========================================
// GET MINUTES
// ==========================================

function getMinutes(
    habitId,
    dateKey = getDateKey()
) {

    if (
        !records[dateKey] ||
        records[dateKey][habitId] === undefined
    ) {

        return 0;

    }

    return Number(
        records[dateKey][habitId]
    );

}


// ==========================================
// RENDER HABITS
// ==========================================

function renderHabits() {

    habitsContainer.innerHTML = "";


    if (habits.length === 0) {

        emptyState.style.display = "block";

        return;

    }


    emptyState.style.display = "none";


    habits.forEach(function (habit) {

        const minutes =
            getMinutes(habit.id);


        const percentage =
            Math.min(
                100,
                Math.round(
                    (minutes / habit.goal) * 100
                )
            );


        const card =
            document.createElement("div");


        card.className = "habit-card";


        card.innerHTML = `

            <div class="habit-top">

                <div class="habit-title">

                    <div class="habit-icon">
                        ${habit.icon}
                    </div>

                    <div>

                        <h3>
                            ${escapeHTML(habit.name)}
                        </h3>

                        <p>
                            Goal:
                            ${habit.goal}
                            minutes/day
                        </p>

                    </div>

                </div>


                <button
                    class="delete-btn"
                    data-id="${habit.id}"
                >
                    🗑️
                </button>

            </div>


            <div class="habit-progress">

                <div class="habit-progress-header">

                    <span>
                        Today's progress
                    </span>

                    <span>
                        ${minutes} /
                        ${habit.goal} min
                    </span>

                </div>


                <div class="habit-progress-track">

                    <div
                        class="habit-progress-fill"
                        style="width:${percentage}%"
                    ></div>

                </div>

            </div>


            <div class="record-area">

                <div class="minutes-input">

                    <input
                        type="number"
                        min="0"
                        value="${minutes}"
                        class="minutes-field"
                        data-id="${habit.id}"
                    >

                    <span>
                        minutes today
                    </span>

                </div>


                <button
                    class="save-minutes"
                    data-id="${habit.id}"
                >
                    Save Progress
                </button>

            </div>


            ${
                habit.reminder
                ?
                `
                <div class="reminder">
                    🔔 Reminder: ${habit.reminder}
                </div>
                `
                :
                ""
            }

        `;


        habitsContainer.appendChild(card);

    });


    attachHabitButtons();

}


// ==========================================
// HABIT BUTTONS
// ==========================================

function attachHabitButtons() {

    // Delete buttons

    const deleteButtons =
        document.querySelectorAll(
            ".delete-btn"
        );


    deleteButtons.forEach(
        function (button) {

            button.onclick =
                function () {

                    deleteHabit(
                        button.dataset.id
                    );

                };

        }
    );


    // Save progress buttons

    const saveButtons =
        document.querySelectorAll(
            ".save-minutes"
        );


    saveButtons.forEach(
        function (button) {

            button.onclick =
                function () {

                    const id =
                        button.dataset.id;


                    const input =
                        document.querySelector(
                            `.minutes-field[data-id="${id}"]`
                        );


                    saveMinutes(
                        id,
                        input
                    );

                };

        }
    );

}


// ==========================================
// DELETE HABIT
// ==========================================

function deleteHabit(id) {

    const habit =
        habits.find(
            function (item) {
                return item.id === id;
            }
        );


    if (!habit) return;


    const confirmDelete =
        confirm(
            `Delete "${habit.name}"?`
        );


    if (!confirmDelete) return;


    habits =
        habits.filter(
            function (item) {
                return item.id !== id;
            }
        );


    saveData();

    renderHabits();

    updateDashboard();

}


// ==========================================
// SAVE MINUTES
// ==========================================

function saveMinutes(
    habitId,
    input
) {

    const minutes =
        Math.max(
            0,
            Number(input.value) || 0
        );


    const today =
        getDateKey();


    if (!records[today]) {

        records[today] = {};

    }


    records[today][habitId] =
        minutes;


    saveData();

    renderHabits();

    updateDashboard();

}


// ==========================================
// DASHBOARD
// ==========================================

function updateDashboard() {

    const today =
        getDateKey();


    let totalMinutes = 0;

    let totalGoal = 0;


    habits.forEach(
        function (habit) {

            totalMinutes +=
                getMinutes(
                    habit.id,
                    today
                );

            totalGoal +=
                habit.goal;

        }
    );


    const todayMinutesElement =
        document.getElementById(
            "todayMinutes"
        );


    const todayProgressElement =
        document.getElementById(
            "todayProgress"
        );


    const progressBar =
        document.getElementById(
            "overallProgressBar"
        );


    if (todayMinutesElement) {

        todayMinutesElement.textContent =
            `${totalMinutes} min`;

    }


    const progress =
        totalGoal > 0
        ?
        Math.min(
            100,
            Math.round(
                (totalMinutes / totalGoal) * 100
            )
        )
        :
        0;


    if (todayProgressElement) {

        todayProgressElement.textContent =
            `${progress}%`;

    }


    if (progressBar) {

        progressBar.style.width =
            `${progress}%`;

    }


    const motivation =
        document.getElementById(
            "motivation"
        );


    if (motivation) {

        motivation.textContent =
            getMotivation(progress);

    }

}


// ==========================================
// MOTIVATION
// ==========================================

function getMotivation(progress) {

    if (habits.length === 0) {

        return "Add your first habit 🌱";

    }


    if (progress === 0) {

        return "Today is a blank page ✨";

    }


    if (progress < 25) {

        return "You've started. Keep going 💪";

    }


    if (progress < 50) {

        return "You're building momentum 🔥";

    }


    if (progress < 75) {

        return "You're doing great! 🚀";

    }


    if (progress < 100) {

        return "Almost there! 🎯";

    }


    return "Daily goals crushed! 🏆";

}


// ==========================================
// DAILY THEME
// ==========================================

function generateDailyTheme() {

    const themes = [

        {
            primary: "#6C63FF",
            secondary: "#00C9A7",
            background: "#0B1020"
        },

        {
            primary: "#FF5F6D",
            secondary: "#FFC371",
            background: "#21131A"
        },

        {
            primary: "#00B4DB",
            secondary: "#0083B0",
            background: "#071B27"
        },

        {
            primary: "#F857A6",
            secondary: "#FF5858",
            background: "#21121B"
        },

        {
            primary: "#43CEA2",
            secondary: "#185A9D",
            background: "#081B1B"
        },

        {
            primary: "#A18CD1",
            secondary: "#FBC2EB",
            background: "#191329"
        },

        {
            primary: "#F7971E",
            secondary: "#FFD200",
            background: "#211707"
        }

    ];


    const now =
        new Date();


    const start =
        new Date(
            now.getFullYear(),
            0,
            0
        );


    const difference =
        now - start;


    const dayOfYear =
        Math.floor(
            difference /
            (1000 * 60 * 60 * 24)
        );


    const theme =
        themes[
            dayOfYear % themes.length
        ];


    document.documentElement.style.setProperty(
        "--primary",
        theme.primary
    );


    document.documentElement.style.setProperty(
        "--secondary",
        theme.secondary
    );


    document.documentElement.style.setProperty(
        "--background",
        theme.background
    );

}


// ==========================================
// DATE DISPLAY
// ==========================================

function updateDate() {

    const element =
        document.getElementById(
            "todayDate"
        );


    if (!element) return;


    element.textContent =
        new Date().toLocaleDateString(
            "en-US",
            {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric"
            }
        );

}


// ==========================================
// SECURITY
// ==========================================

function escapeHTML(text) {

    const element =
        document.createElement("div");

    element.textContent =
        text;

    return element.innerHTML;

}


// ==========================================
// START APP
// ==========================================

generateDailyTheme();

updateDate();

renderHabits();

updateDashboard();