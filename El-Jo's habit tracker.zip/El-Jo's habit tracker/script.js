/* =====================================================
   EL-JO'S HABIT TRACKER
   ===================================================== */


/* -----------------------------------------------------
   STORAGE
----------------------------------------------------- */

let habits =
    JSON.parse(
        localStorage.getItem("eljoHabits")
    ) || [];

let records =
    JSON.parse(
        localStorage.getItem("eljoRecords")
    ) || {};


/* -----------------------------------------------------
   DOM ELEMENTS
----------------------------------------------------- */

const habitsContainer =
    document.getElementById(
        "habitsContainer"
    );

const emptyState =
    document.getElementById(
        "emptyState"
    );

const addHabitBtn =
    document.getElementById(
        "addHabitBtn"
    );

const habitForm =
    document.getElementById(
        "habitForm"
    );

const saveHabitBtn =
    document.getElementById(
        "saveHabitBtn"
    );

const cancelHabitBtn =
    document.getElementById(
        "cancelHabitBtn"
    );

const habitName =
    document.getElementById(
        "habitName"
    );

const habitIcon =
    document.getElementById(
        "habitIcon"
    );

const dailyGoal =
    document.getElementById(
        "dailyGoal"
    );

const reminderTime =
    document.getElementById(
        "reminderTime"
    );

const todayDate =
    document.getElementById(
        "todayDate"
    );

const todayMinutes =
    document.getElementById(
        "todayMinutes"
    );

const todayProgress =
    document.getElementById(
        "todayProgress"
    );

const overallProgressBar =
    document.getElementById(
        "overallProgressBar"
    );

const overallStreak =
    document.getElementById(
        "overallStreak"
    );

const motivation =
    document.getElementById(
        "motivation"
    );

const weekTotal =
    document.getElementById(
        "weekTotal"
    );

const weekAverage =
    document.getElementById(
        "weekAverage"
    );

const weekCompletion =
    document.getElementById(
        "weekCompletion"
    );

const bestStreak =
    document.getElementById(
        "bestStreak"
    );

const weekChart =
    document.getElementById(
        "weekChart"
    );

const weekRange =
    document.getElementById(
        "weekRange"
    );

const notificationBtn =
    document.getElementById(
        "notificationBtn"
    );


/* -----------------------------------------------------
   DATE FUNCTIONS
----------------------------------------------------- */

function getDateKey(date = new Date()) {

    const year =
        date.getFullYear();

    const month =
        String(
            date.getMonth() + 1
        ).padStart(2, "0");

    const day =
        String(
            date.getDate()
        ).padStart(2, "0");

    return `${year}-${month}-${day}`;
}


function getDateObject(key) {

    const [
        year,
        month,
        day
    ] = key.split("-").map(Number);

    return new Date(
        year,
        month - 1,
        day
    );
}


function getWeekDates() {

    const today =
        new Date();

    const day =
        today.getDay();

    const difference =
        day === 0
            ? -6
            : 1 - day;

    const monday =
        new Date(today);

    monday.setDate(
        today.getDate() + difference
    );

    const dates = [];

    for (
        let i = 0;
        i < 7;
        i++
    ) {

        const date =
            new Date(monday);

        date.setDate(
            monday.getDate() + i
        );

        dates.push(date);
    }

    return dates;
}


/* -----------------------------------------------------
   SAVE DATA
----------------------------------------------------- */

function saveData() {

    localStorage.setItem(
        "eljoHabits",
        JSON.stringify(habits)
    );

    localStorage.setItem(
        "eljoRecords",
        JSON.stringify(records)
    );

}


/* -----------------------------------------------------
   DAILY RECORD
----------------------------------------------------- */

function getMinutes(
    habitId,
    dateKey = getDateKey()
) {

    if (
        !records[dateKey] ||
        records[dateKey][habitId] === undefined
    ) {

        return 0;

    }

    return Number(
        records[dateKey][habitId]
    );

}


/* -----------------------------------------------------
   RANDOM DAILY THEME
----------------------------------------------------- */

function generateDailyTheme() {

    const themes = [

        {
            primary: "#6c63ff",
            secondary: "#00c9a7",
            background: "#0b1020"
        },

        {
            primary: "#ff5f6d",
            secondary: "#ffc371",
            background: "#21131a"
        },

        {
            primary: "#00b4db",
            secondary: "#0083b0",
            background: "#071b27"
        },

        {
            primary: "#f857a6",
            secondary: "#ff5858",
            background: "#21121b"
        },

        {
            primary: "#43cea2",
            secondary: "#185a9d",
            background: "#081b1b"
        },

        {
            primary: "#a18cd1",
            secondary: "#fbc2eb",
            background: "#191329"
        },

        {
            primary: "#f7971e",
            secondary: "#ffd200",
            background: "#211707"
        }

    ];

    /*
       Use the day of the year so the same
       colour remains throughout the day.
    */

    const today =
        new Date();

    const start =
        new Date(
            today.getFullYear(),
            0,
            0
        );

    const difference =
        today - start;

    const dayOfYear =
        Math.floor(
            difference /
            (1000 * 60 * 60 * 24)
        );

    const theme =
        themes[
            dayOfYear % themes.length
        ];

    document.documentElement.style
        .setProperty(
            "--primary",
            theme.primary
        );

    document.documentElement.style
        .setProperty(
            "--secondary",
            theme.secondary
        );

    document.documentElement.style
        .setProperty(
            "--background",
            theme.background
        );

}


/* -----------------------------------------------------
   ADD HABIT
----------------------------------------------------- */

addHabitBtn.addEventListener(
    "click",
    () => {

        habitForm.classList.toggle(
            "hidden"
        );

        if (
            !habitForm.classList.contains(
                "hidden"
            )
        ) {

            habitName.focus();

        }

    }
);


/* -----------------------------------------------------
   CANCEL FORM
----------------------------------------------------- */

cancelHabitBtn.addEventListener(
    "click",
    () => {

        habitForm.classList.add(
            "hidden"
        );

        clearForm();

    }
);


/* -----------------------------------------------------
   SAVE NEW HABIT
----------------------------------------------------- */

saveHabitBtn.addEventListener(
    "click",
    () => {

        const name =
            habitName.value.trim();

        const icon =
            habitIcon.value;

        const goal =
            Number(
                dailyGoal.value
            );

        const reminder =
            reminderTime.value;


        if (!name) {

            alert(
                "Please enter a habit name."
            );

            return;

        }


        if (
            !goal ||
            goal < 1
        ) {

            alert(
                "Please enter a valid daily goal."
            );

            return;

        }


        const newHabit = {

            id:
                Date.now().toString(),

            name,

            icon,

            goal,

            reminder

        };


        habits.push(
            newHabit
        );

        saveData();

        renderHabits();

        updateDashboard();

        habitForm.classList.add(
            "hidden"
        );

        clearForm();

    }
);


/* -----------------------------------------------------
   CLEAR FORM
----------------------------------------------------- */

function clearForm() {

    habitName.value = "";

    habitIcon.value = "📚";

    dailyGoal.value = 30;

    reminderTime.value = "";

}


/* -----------------------------------------------------
   DELETE HABIT
----------------------------------------------------- */

function deleteHabit(id) {

    const habit =
        habits.find(
            item => item.id === id
        );

    if (!habit) return;


    const confirmed =
        confirm(
            `Delete "${habit.name}"?`
        );


    if (!confirmed) return;


    habits =
        habits.filter(
            item => item.id !== id
        );


    saveData();

    renderHabits();

    updateDashboard();

}


/* -----------------------------------------------------
   RECORD MINUTES
----------------------------------------------------- */

function saveMinutes(
    habitId,
    input
) {

    const minutes =
        Math.max(
            0,
            Number(input.value) || 0
        );

    const today =
        getDateKey();


    if (!records[today]) {

        records[today] = {};

    }


    records[today][habitId] =
        minutes;


    saveData();

    renderHabits();

    updateDashboard();

}


/* -----------------------------------------------------
   RENDER HABITS
----------------------------------------------------- */

function renderHabits() {

    habitsContainer.innerHTML = "";


    if (habits.length === 0) {

        emptyState.style.display =
            "block";

        return;

    }


    emptyState.style.display =
        "none";


    habits.forEach(
        habit => {

            const minutes =
                getMinutes(
                    habit.id
                );


            const percentage =
                Math.min(
                    100,
                    Math.round(
                        (minutes /
                            habit.goal) *
                        100
                    )
                );


            const card =
                document.createElement(
                    "div"
                );


            card.className =
                "habit-card";


            card.innerHTML = `

                <div class="habit-top">

                    <div class="habit-title">

                        <div class="habit-icon">
                            ${habit.icon}
                        </div>

                        <div>

                            <h3>
                                ${escapeHTML(
                                    habit.name
                                )}
                            </h3>

                            <p>
                                Goal:
                                ${habit.goal}
                                minutes/day
                            </p>

                        </div>

                    </div>


                    <button
                        class="delete-btn"
                        onclick="deleteHabit('${habit.id}')"
                    >
                        🗑️
                    </button>

                </div>


                <div class="habit-progress">

                    <div class="habit-progress-header">

                        <span>
                            Today's progress
                        </span>

                        <span>
                            ${minutes} /
                            ${habit.goal} min
                        </span>

                    </div>


                    <div
                        class="habit-progress-track"
                    >

                        <div
                            class="habit-progress-fill"
                            style="
                                width:${percentage}%
                            "
                        ></div>

                    </div>

                </div>


                <div class="record-area">

                    <div class="minutes-input">

                        <input
                            type="number"
                            min="0"
                            max="1440"
                            value="${minutes}"
                            id="input-${habit.id}"
                        >

                        <span>
                            minutes today
                        </span>

                    </div>


                    <button
                        class="save-minutes"
                        onclick="
                            saveMinutes(
                                '${habit.id}',
                                document.getElementById(
                                    'input-${habit.id}'
                                )
                            )
                        "
                    >
                        Save Progress
                    </button>

                </div>


                ${
                    habit.reminder
                        ? `
                        <div class="reminder">
                            🔔 Reminder:
                            ${habit.reminder}
                        </div>
                        `
                        : ""
                }

            `;


            habitsContainer.appendChild(
                card
            );

        }
    );

}


/* -----------------------------------------------------
   DASHBOARD
----------------------------------------------------- */

function updateDashboard() {

    const today =
        getDateKey();


    let totalMinutes = 0;

    let totalGoal = 0;


    habits.forEach(
        habit => {

            totalMinutes +=
                getMinutes(
                    habit.id
                );

            totalGoal +=
                habit.goal;

        }
    );


    todayMinutes.textContent =
        `${totalMinutes} min`;


    const progress =
        totalGoal > 0
            ? Math.min(
                100,
                Math.round(
                    (totalMinutes /
                        totalGoal) *
                    100
                )
            )
            : 0;


    todayProgress.textContent =
        `${progress}%`;


    overallProgressBar.style.width =
        `${progress}%`;


    motivation.textContent =
        getMotivation(progress);


    overallStreak.textContent =
        `${calculateOverallStreak()} days`;


    updateWeeklySummary();

}


/* -----------------------------------------------------
   MOTIVATION
----------------------------------------------------- */

function getMotivation(progress) {

    if (habits.length === 0) {

        return "Add your first habit 🌱";

    }

    if (progress === 0) {

        return "Today is a blank page ✨";

    }

    if (progress < 25) {

        return "You've started. Keep going 💪";

    }

    if (progress < 50) {

        return "You're warming up 🔥";

    }

    if (progress < 75) {

        return "You're building momentum 🚀";

    }

    if (progress < 100) {

        return "Almost there! 🎯";

    }

    return "Daily goals crushed! 🏆";

}


/* -----------------------------------------------------
   OVERALL STREAK
----------------------------------------------------- */

function calculateOverallStreak() {

    if (habits.length === 0) {

        return 0;

    }


    let streak = 0;

    const today =
        new Date();


    for (
        let i = 0;
        i < 365;
        i++
    ) {

        const date =
            new Date(today);

        date.setDate(
            today.getDate() - i
        );


        const key =
            getDateKey(date);


        const completed =
            habits.some(
                habit => {

                    return (
                        getMinutes(
                            habit.id,
                            key
                        ) > 0
                    );

                }
            );


        if (completed) {

            streak++;

        } else {

            break;

        }

    }


    return streak;

}


/* -----------------------------------------------------
   WEEKLY SUMMARY
----------------------------------------------------- */

function updateWeeklySummary() {

    const dates =
        getWeekDates();


    let total = 0;

    let possible = 0;


    dates.forEach(
        date => {

            const key =
                getDateKey(date);


            habits.forEach(
                habit => {

                    total +=
                        getMinutes(
                            habit.id,
                            key
                        );

                    possible +=
                        habit.goal;

                }
            );

        }
    );


    weekTotal.textContent =
        `${total} min`;


    const average =
        Math.round(
            total / 7
        );


    weekAverage.textContent =
        `${average} min`;


    const completion =
        possible > 0
            ? Math.min(
                100,
                Math.round(
                    (total /
                        possible) *
                    100
                )
            )
            : 0;


    weekCompletion.textContent =
        `${completion}%`;


    bestStreak.textContent =
        `${calculateBestStreak()} days`;


    const first =
        dates[0];

    const last =
        dates[6];


    weekRange.textContent =
        `${formatShortDate(first)}
        -
        ${formatShortDate(last)}`;


    renderChart(
        dates
    );

}


/* -----------------------------------------------------
   BEST STREAK
----------------------------------------------------- */

function calculateBestStreak() {

    let best = 0;

    let current = 0;


    for (
        let i = 0;
        i < 365;
        i++
    ) {

        const date =
            new Date();

        date.setDate(
            date.getDate() - i
        );


        const key =
            getDateKey(date);


        const completed =
            habits.some(
                habit =>
                    getMinutes(
                        habit.id,
                        key
                    ) > 0
            );


        if (completed) {

            current++;

            best =
                Math.max(
                    best,
                    current
                );

        } else {

            current = 0;

        }

    }


    return best;

}


/* -----------------------------------------------------
   WEEKLY CHART
----------------------------------------------------- */

function renderChart(
    dates
) {

    weekChart.innerHTML = "";


    const totals = dates.map(
        date => {

            const key =
                getDateKey(date);

            return habits.reduce(
                (
                    sum,
                    habit
                ) =>
                    sum +
                    getMinutes(
                        habit.id,
                        key
                    ),
                0
            );

        }
    );


    const maximum =
        Math.max(
            ...totals,
            1
        );


    dates.forEach(
        (
            date,
            index
        ) => {

            const total =
                totals[index];


            const height =
                Math.max(
                    3,
                    (total /
                        maximum) *
                    100
                );


            const day =
                document.createElement(
                    "div"
                );


            day.className =
                "chart-day";


            day.innerHTML = `

                <span class="chart-minutes">
                    ${total}m
                </span>

                <div class="chart-bar-area">

                    <div
                        class="chart-bar"
                        style="
                            height:${height}%
                        "
                    ></div>

                </div>

                <span>
                    ${formatDay(date)}
                </span>

            `;


            weekChart.appendChild(
                day
            );

        }
    );

}


/* -----------------------------------------------------
   DATE FORMATTING
----------------------------------------------------- */

function formatDay(date) {

    return date.toLocaleDateString(
        "en-US",
        {
            weekday: "short"
        }
    ).slice(0, 3);

}


function formatShortDate(date) {

    return date.toLocaleDateString(
        "en-US",
        {
            day: "numeric",
            month: "short"
        }
    );

}


/* -----------------------------------------------------
   TODAY'S DATE
----------------------------------------------------- */

function updateDate() {

    const now =
        new Date();


    todayDate.textContent =
        now.toLocaleDateString(
            "en-US",
            {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric"
            }
        );

}


/* -----------------------------------------------------
   NOTIFICATIONS
----------------------------------------------------- */

notificationBtn.addEventListener(
    "click",
    async () => {

        if (
            !("Notification" in window)
        ) {

            alert(
                "Your browser does not support notifications."
            );

            return;

        }


        const permission =
            await Notification.requestPermission();


        if (
            permission === "granted"
        ) {

            notificationBtn.textContent =
                "🔔 Reminders Enabled";

            notificationBtn.style.background =
                "var(--secondary)";

            notificationBtn.style.color =
                "#061612";


            alert(
                "Reminders are enabled!"
            );

        }

    }
);


/* -----------------------------------------------------
   HABIT REMINDER CHECK
----------------------------------------------------- */

function checkReminders() {

    if (
        !("Notification" in window) ||
        Notification.permission !==
        "granted"
    ) {

        return;

    }


    const now =
        new Date();


    const currentTime =
        now.toTimeString()
            .slice(0, 5);


    habits.forEach(
        habit => {

            if (
                habit.reminder ===
                currentTime
            ) {

                const today =
                    getDateKey();


                const reminderKey =
                    `reminded-${habit.id}-${today}-${currentTime}`;


                if (
                    localStorage.getItem(
                        reminderKey
                    )
                ) {

                    return;

                }


                new Notification(
                    `${habit.icon} ${habit.name}`,
                    {
                        body:
                            `Time for your ${habit.name} habit! Goal: ${habit.goal} minutes.`,
                        icon:
                            "https://cdn-icons-png.flaticon.com/512/1828/1828640.png"
                    }
                );


                localStorage.setItem(
                    reminderKey,
                    "true"
                );

            }

        }
    );

}


/* -----------------------------------------------------
   ESCAPE HTML
----------------------------------------------------- */

function escapeHTML(text) {

    const div =
        document.createElement(
            "div"
        );

    div.textContent = text;

    return div.innerHTML;

}


/* -----------------------------------------------------
   INITIALIZE
----------------------------------------------------- */

generateDailyTheme();

updateDate();

renderHabits();

updateDashboard();


/*
   Check reminders every 30 seconds.
*/

setInterval(
    checkReminders,
    30000
);


/*
   Also check immediately.
*/

checkReminders();